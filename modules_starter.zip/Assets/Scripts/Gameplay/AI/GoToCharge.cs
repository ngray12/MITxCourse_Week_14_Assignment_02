﻿using UnityEngine;

namespace Scripts.Gameplay.AI
{
    public class GoToCharge : MonoBehaviour
    {
        
    }
}